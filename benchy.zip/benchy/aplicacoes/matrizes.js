(function () {
// Problema: multiplicação de duas matrizes n×n (C = A × B).
// O "tamanho" da configuração é a dimensão n da matriz (n=200 → 8 milhões de multiplicações).
// A matriz é montada a partir dos dados gerados, então continua reproduzível pela semente.
Benchy.registrarProblema("matrizes", {
  unidade: "multiplicações",
  preparar: (dados) => {
    const n = dados.length;
    const A = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => dados[(i + j) % n]));
    const B = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => dados[(i + 2 * j) % n]));
    return { n, A, B };
  },
});

const zeros = (n) => Array.from({ length: n }, () => new Array(n).fill(0));

Benchy.registrar({ nome: "multClassica", problema: "matrizes",
  descricao: "Três laços i-j-k, percorrendo B por coluna. O(n³)",
  executar: ({ n, A, B }) => {
    const C = zeros(n);
    for (let i = 0; i < n; i++)
      for (let j = 0; j < n; j++) {
        let s = 0;
        for (let k = 0; k < n; k++) s += A[i][k] * B[k][j];
        C[i][j] = s;
      }
    return C;
  },
  contar: ({ n, A, B }, op) => {
    const C = zeros(n);
    for (let i = 0; i < n; i++)
      for (let j = 0; j < n; j++) {
        let s = 0;
        for (let k = 0; k < n; k++) { op(); s += A[i][k] * B[k][j]; }
        C[i][j] = s;
      }
    return C;
  } });

Benchy.registrar({ nome: "multIKJ", problema: "matrizes",
  descricao: "Laços reordenados i-k-j, percorrendo B por linha (melhor uso do cache). O(n³)",
  executar: ({ n, A, B }) => {
    const C = zeros(n);
    for (let i = 0; i < n; i++)
      for (let k = 0; k < n; k++) {
        const aik = A[i][k], Bk = B[k], Ci = C[i];
        for (let j = 0; j < n; j++) Ci[j] += aik * Bk[j];
      }
    return C;
  },
  contar: ({ n, A, B }, op) => {
    const C = zeros(n);
    for (let i = 0; i < n; i++)
      for (let k = 0; k < n; k++) {
        const aik = A[i][k], Bk = B[k], Ci = C[i];
        for (let j = 0; j < n; j++) { op(); Ci[j] += aik * Bk[j]; }
      }
    return C;
  } });

Benchy.registrar({ nome: "multTransposta", problema: "matrizes",
  descricao: "Transpõe B antes de multiplicar, para percorrer linhas nas duas matrizes. O(n³)",
  executar: ({ n, A, B }) => {
    const BT = zeros(n), C = zeros(n);
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) BT[j][i] = B[i][j];
    for (let i = 0; i < n; i++)
      for (let j = 0; j < n; j++) {
        const Ai = A[i], Bj = BT[j]; let s = 0;
        for (let k = 0; k < n; k++) s += Ai[k] * Bj[k];
        C[i][j] = s;
      }
    return C;
  },
  contar: ({ n, A, B }, op) => {
    const BT = zeros(n), C = zeros(n);
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) BT[j][i] = B[i][j];
    for (let i = 0; i < n; i++)
      for (let j = 0; j < n; j++) {
        const Ai = A[i], Bj = BT[j]; let s = 0;
        for (let k = 0; k < n; k++) { op(); s += Ai[k] * Bj[k]; }
        C[i][j] = s;
      }
    return C;
  } });
})();
