(async () => {
  const out = []; let falhas = 0;
  const ok = (c, m) => { if (!c) throw new Error(m || "afirmação falhou"); };
  const t = async (nome, fn) => { try { await fn(); out.push("✅ " + nome); } catch (e) { falhas++; out.push("❌ " + nome + " → " + e.message); } };
  const lanca = async (fn, trecho) => {
    try { await fn(); } catch (e) { ok(e.message.includes(trecho), "mensagem inesperada: " + e.message); return; }
    throw new Error("deveria ter lançado erro");
  };
  const base = { problema: "ordenacao", algoritmos: ["bubbleSort", "quickSort"], tamanhos: [50], tiposDeDados: ["aleatorio"], repeticoes: 2 };
  const com = (o) => ({ ...base, ...o });

  await t("normal: ordenação gera 1 linha por algoritmo, com estatísticas", async () => {
    const r = await Benchy.executar(base); ok(r.length === 2 && r.every((l) => l.media >= 0));
  });
  await t("normal: buscas com 2 algoritmos", async () => {
    const r = await Benchy.executar({ problema: "buscas", algoritmos: ["buscaLinear", "buscaBinaria"], tamanhos: [100, 1000], tiposDeDados: ["aleatorio"], repeticoes: 3 });
    ok(r.length === 4 && r.every((l) => l.media >= 0));
  });
  await t("normal: gerador (ordenado, invertido, aleatório reprodutível)", () => {
    ok(Benchy.gerarDados("ordenado", 3).join() === "1,2,3");
    ok(Benchy.gerarDados("invertido", 3).join() === "3,2,1");
    ok(Benchy.gerarDados("aleatorio", 20, 7).join() === Benchy.gerarDados("aleatorio", 20, 7).join());
  });
  await t("normal: estatísticas", () => {
    const s = Benchy.estatisticas([4, 1, 3, 2]); ok(s.media === 2.5 && s.mediana === 2.5 && s.minimo === 1 && s.maximo === 4);
  });


  const invalidos = [
    ["problema inexistente", com({ problema: "xyz" }), '"problema" inválido'],
    ["algoritmo não registrado", com({ algoritmos: ["bubbleSort", "nada"] }), "não registrado"],
    ["apenas um algoritmo", com({ algoritmos: ["bubbleSort"] }), "pelo menos 2"],
    ["algoritmo de outro problema", com({ algoritmos: ["bubbleSort", "buscaLinear"] }), "resolve"],
    ["tamanho negativo", com({ tamanhos: [-5] }), '"tamanhos"'],
    ["tamanho decimal", com({ tamanhos: [1.5] }), '"tamanhos"'],
    ["tipo de dado inválido", com({ tiposDeDados: ["caos"] }), '"tiposDeDados"'],
    ["repetições zero", com({ repeticoes: 0 }), '"repeticoes"'],
    ["config não é objeto", [1, 2], "objeto JSON"],
    ["config nula", null, "objeto JSON"],
  ];
  for (const [nome, cfg, trecho] of invalidos) await t("inválido: " + nome, () => lanca(() => Benchy.executar(cfg), trecho));
  await t("inválido: registrar algoritmo sem função", () => lanca(() => Benchy.registrar({ nome: "x", problema: "ordenacao" }), "executar"));


  await t("extremo: n = 1 (ordenação)", async () => { ok((await Benchy.executar(com({ tamanhos: [1] }))).every((l) => l.media >= 0)); });
  await t("extremo: n = 1 (busca)", async () => {
    const r = await Benchy.executar({ problema: "buscas", algoritmos: ["buscaLinear", "buscaBinaria"], tamanhos: [1], tiposDeDados: ["ordenado"], repeticoes: 1 });
    ok(r.every((l) => l.media >= 0));
  });
  await t("extremo: 1 repetição, todos os tipos", async () => {
    ok((await Benchy.executar(com({ tiposDeDados: Benchy.TIPOS, repeticoes: 1 }))).length === 6);
  });
  await t("extremo: algoritmo que lança exceção gera mensagem clara", async () => {
    Benchy.registrar({ nome: "quebrado", problema: "ordenacao", executar: () => { throw new Error("boom"); } });
    await lanca(() => Benchy.executar(com({ algoritmos: ["quickSort", "quebrado"] })), "'quebrado' falhou");
  });


  // ---- operações e matrizes ----
  const linha = (r, nome) => r.find((l) => l.algoritmo === nome);
  await t("operações: bubbleSort em lista ordenada faz n-1 comparações", async () => {
    const r = await Benchy.executar(com({ tamanhos: [50], tiposDeDados: ["ordenado"], repeticoes: 1 }));
    ok(linha(r, "bubbleSort").operacoes === 49, "esperado 49, veio " + linha(r, "bubbleSort").operacoes);
  });
  await t("operações: bubbleSort em lista invertida faz n(n-1)/2 comparações", async () => {
    const r = await Benchy.executar(com({ tamanhos: [10], tiposDeDados: ["invertido"], repeticoes: 1 }));
    ok(linha(r, "bubbleSort").operacoes === 45, "esperado 45, veio " + linha(r, "bubbleSort").operacoes);
  });
  await t("operações: busca linear acha o alvo (posição 75%) em 76 comparações; binária usa bem menos", async () => {
    const r = await Benchy.executar({ problema: "buscas", algoritmos: ["buscaLinear", "buscaBinaria"], tamanhos: [100], tiposDeDados: ["ordenado"], repeticoes: 1 });
    ok(linha(r, "buscaLinear").operacoes === 76, "linear: " + linha(r, "buscaLinear").operacoes);
    ok(linha(r, "buscaBinaria").operacoes < 20, "binária: " + linha(r, "buscaBinaria").operacoes);
  });
  await t("operações: todo resultado informa a unidade (comparações / multiplicações)", async () => {
    const r = await Benchy.executar(base);
    ok(r.every((l) => l.unidade === "comparações"));
  });
  await t("operações: algoritmo sem 'contar' gera operacoes = null", async () => {
    Benchy.registrar({ nome: "semContagem", problema: "ordenacao", executar: (a) => a.sort((x, y) => x - y) });
    const r = await Benchy.executar(com({ algoritmos: ["quickSort", "semContagem"] }));
    ok(linha(r, "semContagem").operacoes === null && linha(r, "quickSort").operacoes > 0);
  });
  await t("operações: 'contar' que não é função é rejeitado", () =>
    lanca(() => Benchy.registrar({ nome: "y", problema: "ordenacao", executar: () => {}, contar: 5 }), "contar"));
  await t("matrizes: 2 algoritmos × tamanhos geram 1 linha por combinação", async () => {
    const r = await Benchy.executar({ problema: "matrizes", algoritmos: ["multClassica", "multIKJ"], tamanhos: [5, 10], tiposDeDados: ["aleatorio"], repeticoes: 2 });
    ok(r.length === 4 && r.every((l) => l.media >= 0));
  });
  await t("matrizes: todos os algoritmos fazem n³ multiplicações (n = 10 → 1000)", async () => {
    const r = await Benchy.executar({ problema: "matrizes", algoritmos: ["multClassica", "multIKJ", "multTransposta"], tamanhos: [10], tiposDeDados: ["aleatorio"], repeticoes: 1 });
    ok(r.every((l) => l.operacoes === 1000 && l.unidade === "multiplicações"));
  });
  await t("matrizes: resultado correto ([[1,2],[3,4]] × [[5,6],[7,8]] = [[19,22],[43,50]])", () => {
    const entrada = { n: 2, A: [[1, 2], [3, 4]], B: [[5, 6], [7, 8]] };
    for (const a of Benchy.listar("matrizes"))
      ok(JSON.stringify(a.executar(structuredClone(entrada))) === "[[19,22],[43,50]]", a.nome + " calculou errado");
  });
  await t("matrizes: algoritmo de ordenação não pode ser usado em 'matrizes'", () =>
    lanca(() => Benchy.executar({ problema: "matrizes", algoritmos: ["multClassica", "bubbleSort"], tamanhos: [5], tiposDeDados: ["aleatorio"], repeticoes: 1 }), "resolve"));

  out.push(falhas ? `\n${falhas} teste(s) falharam.` : `\nTodos os testes passaram.`);
  console.log(out.join("\n"));
  if (typeof document !== "undefined") document.getElementById("saida").textContent = out.join("\n");
})();
