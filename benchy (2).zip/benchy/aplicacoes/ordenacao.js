/* APLICAÇÃO 1: ordenação. Usa o núcleo sem modificá-lo. */
Benchy.registrarProblema("ordenacao", { preparar: (dados) => dados });

Benchy.registrar({ nome: "bubbleSort", problema: "ordenacao",
  descricao: "Troca vizinhos fora de ordem repetidamente. O(n²)",
  executar: (a) => {
    for (let i = 0; i < a.length - 1; i++) {
      let trocou = false;
      for (let j = 0; j < a.length - 1 - i; j++)
        if (a[j] > a[j + 1]) { [a[j], a[j + 1]] = [a[j + 1], a[j]]; trocou = true; }
      if (!trocou) break;
    }
    return a;
  } });

Benchy.registrar({ nome: "quickSort", problema: "ordenacao",
  descricao: "Divide em torno de um pivô (do meio). O(n log n) em média",
  executar: (a) => {
    (function q(l, r) {
      if (l >= r) return;
      const p = a[(l + r) >> 1]; let i = l, j = r;
      while (i <= j) {
        while (a[i] < p) i++;
        while (a[j] > p) j--;
        if (i <= j) { [a[i], a[j]] = [a[j], a[i]]; i++; j--; }
      }
      q(l, j); q(i, r);
    })(0, a.length - 1);
    return a;
  } });

Benchy.registrar({ nome: "sortNativo", problema: "ordenacao",
  descricao: "Array.prototype.sort do navegador (referência)",
  executar: (a) => a.sort((x, y) => x - y) });
