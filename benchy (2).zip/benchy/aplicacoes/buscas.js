/* APLICAÇÃO 2: buscas. Mesmo núcleo, outro problema. */
Benchy.registrarProblema("buscas", {
  // A busca binária exige lista ordenada, então a aplicação ordena antes. Alvo: elemento a 75% da lista.
  preparar: (dados) => {
    const lista = [...dados].sort((a, b) => a - b);
    return { lista, alvo: lista[Math.floor(lista.length * 0.75)] };
  },
});

Benchy.registrar({ nome: "buscaLinear", problema: "buscas",
  descricao: "Percorre item por item. O(n)",
  executar: ({ lista, alvo }) => { for (let i = 0; i < lista.length; i++) if (lista[i] === alvo) return i; return -1; } });

Benchy.registrar({ nome: "buscaBinaria", problema: "buscas",
  descricao: "Divide a lista ordenada ao meio. O(log n)",
  executar: ({ lista, alvo }) => {
    let l = 0, r = lista.length - 1;
    while (l <= r) { const m = (l + r) >> 1;
      if (lista[m] === alvo) return m;
      if (lista[m] < alvo) l = m + 1; else r = m - 1; }
    return -1;
  } });
