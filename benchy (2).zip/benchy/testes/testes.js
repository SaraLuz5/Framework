/* Testes: situações normais, entradas inválidas e casos extremos. */
(async () => {
  const out = []; let falhas = 0;
  const ok = (c, m) => { if (!c) throw new Error(m || "afirmação falhou"); };
  const t = async (nome, fn) => { try { await fn(); out.push("✅ " + nome); } catch (e) { falhas++; out.push("❌ " + nome + " → " + e.message); } };
  const lanca = async (fn, trecho) => {
    try { await fn(); } catch (e) { ok(e.message.includes(trecho), "mensagem inesperada: " + e.message); return; }
    throw new Error("deveria ter lançado erro");
  };
  const base = { problema: "ordenacao", algoritmos: ["bubbleSort", "quickSort"], tamanhos: [50], tiposDeDados: ["aleatorio"], repeticoes: 2 };
  const com = (o) => ({ ...base, ...o });

  // --- Situações normais ---
  await t("normal: ordenação gera 1 linha por algoritmo, com estatísticas", async () => {
    const r = await Benchy.executar(base); ok(r.length === 2 && r.every((l) => l.media >= 0));
  });
  await t("normal: buscas com 2 algoritmos", async () => {
    const r = await Benchy.executar({ problema: "buscas", algoritmos: ["buscaLinear", "buscaBinaria"], tamanhos: [100, 1000], tiposDeDados: ["aleatorio"], repeticoes: 3 });
    ok(r.length === 4 && r.every((l) => l.media >= 0));
  });
  await t("normal: gerador (ordenado, invertido, aleatório reprodutível)", () => {
    ok(Benchy.gerarDados("ordenado", 3).join() === "1,2,3");
    ok(Benchy.gerarDados("invertido", 3).join() === "3,2,1");
    ok(Benchy.gerarDados("aleatorio", 20, 7).join() === Benchy.gerarDados("aleatorio", 20, 7).join());
  });
  await t("normal: estatísticas", () => {
    const s = Benchy.estatisticas([4, 1, 3, 2]); ok(s.media === 2.5 && s.mediana === 2.5 && s.minimo === 1 && s.maximo === 4);
  });

  // --- Entradas inválidas ---
  const invalidos = [
    ["problema inexistente", com({ problema: "xyz" }), '"problema" inválido'],
    ["algoritmo não registrado", com({ algoritmos: ["bubbleSort", "nada"] }), "não registrado"],
    ["apenas um algoritmo", com({ algoritmos: ["bubbleSort"] }), "pelo menos 2"],
    ["algoritmo de outro problema", com({ algoritmos: ["bubbleSort", "buscaLinear"] }), "resolve"],
    ["tamanho negativo", com({ tamanhos: [-5] }), '"tamanhos"'],
    ["tamanho decimal", com({ tamanhos: [1.5] }), '"tamanhos"'],
    ["tipo de dado inválido", com({ tiposDeDados: ["caos"] }), '"tiposDeDados"'],
    ["repetições zero", com({ repeticoes: 0 }), '"repeticoes"'],
    ["config não é objeto", [1, 2], "objeto JSON"],
    ["config nula", null, "objeto JSON"],
  ];
  for (const [nome, cfg, trecho] of invalidos) await t("inválido: " + nome, () => lanca(() => Benchy.executar(cfg), trecho));
  await t("inválido: registrar algoritmo sem função", () => lanca(() => Benchy.registrar({ nome: "x", problema: "ordenacao" }), "executar"));

  // --- Casos extremos ---
  await t("extremo: n = 1 (ordenação)", async () => { ok((await Benchy.executar(com({ tamanhos: [1] }))).every((l) => l.media >= 0)); });
  await t("extremo: n = 1 (busca)", async () => {
    const r = await Benchy.executar({ problema: "buscas", algoritmos: ["buscaLinear", "buscaBinaria"], tamanhos: [1], tiposDeDados: ["ordenado"], repeticoes: 1 });
    ok(r.every((l) => l.media >= 0));
  });
  await t("extremo: 1 repetição, todos os tipos", async () => {
    ok((await Benchy.executar(com({ tiposDeDados: Benchy.TIPOS, repeticoes: 1 }))).length === 6);
  });
  await t("extremo: algoritmo que lança exceção gera mensagem clara", async () => {
    Benchy.registrar({ nome: "quebrado", problema: "ordenacao", executar: () => { throw new Error("boom"); } });
    await lanca(() => Benchy.executar(com({ algoritmos: ["quickSort", "quebrado"] })), "'quebrado' falhou");
  });

  out.push(falhas ? `\n${falhas} teste(s) falharam.` : `\nTodos os testes passaram.`);
  console.log(out.join("\n"));
  if (typeof document !== "undefined") document.getElementById("saida").textContent = out.join("\n");
})();
