/* NÚCLEO do Benchy: não sabe nada de ordenação ou busca. */
(function (g) {
  "use strict";
  const algoritmos = new Map(), problemas = new Map();
  const TIPOS = ["aleatorio", "ordenado", "invertido"];
  const erro = (m) => { throw new Error("[Benchy] " + m); };

  // Uma aplicação define um "problema": como preparar a entrada a partir dos dados gerados.
  function registrarProblema(nome, def) {
    if (!nome || !def || typeof def.preparar !== "function")
      erro(`Problema '${nome}' precisa de nome e da função preparar(dados).`);
    problemas.set(nome, def);
  }

  // Registro de algoritmos: nome + descrição + função de execução.
  function registrar({ nome, descricao, problema, executar } = {}) {
    if (!nome || typeof nome !== "string") erro("Algoritmo sem nome.");
    if (typeof executar !== "function") erro(`Algoritmo '${nome}' precisa de uma função 'executar'.`);
    if (!problemas.has(problema)) erro(`Algoritmo '${nome}' usa um problema não registrado: '${problema}'.`);
    algoritmos.set(nome, { nome, descricao: descricao || "", problema, executar });
  }
  const listar = (p) => [...algoritmos.values()].filter((a) => !p || a.problema === p);

  // Gerador de dados reprodutível (semente fixa): permutações de 1..n.
  function gerarDados(tipo, n, semente = 42) {
    if (!TIPOS.includes(tipo)) erro(`Tipo de dado inválido: '${tipo}'. Use: ${TIPOS.join(", ")}.`);
    if (!Number.isInteger(n) || n < 1) erro(`Tamanho inválido: ${n}. Use um inteiro maior que 0.`);
    const a = Array.from({ length: n }, (_, i) => i + 1);
    if (tipo === "ordenado") return a;
    if (tipo === "invertido") return a.reverse();
    let s = semente >>> 0;
    const rnd = () => { s = (s + 0x6D2B79F5) >>> 0; let t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    for (let i = n - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }

  // Validação da configuração externa, com mensagens claras.
  function validarConfig(c) {
    if (!c || typeof c !== "object" || Array.isArray(c)) return ["A configuração deve ser um objeto JSON."];
    const e = [];
    if (!problemas.has(c.problema))
      e.push(`"problema" inválido: '${c.problema}'. Disponíveis: ${[...problemas.keys()].join(", ")}.`);
    if (!Array.isArray(c.algoritmos) || c.algoritmos.length < 2)
      e.push('"algoritmos" deve ser uma lista com pelo menos 2 nomes.');
    else c.algoritmos.forEach((n) => {
      const a = algoritmos.get(n);
      if (!a) e.push(`Algoritmo não registrado: '${n}'.`);
      else if (a.problema !== c.problema) e.push(`'${n}' resolve '${a.problema}', não '${c.problema}'.`);
    });
    if (!Array.isArray(c.tamanhos) || !c.tamanhos.length || !c.tamanhos.every((n) => Number.isInteger(n) && n > 0))
      e.push('"tamanhos" deve ser uma lista de inteiros positivos.');
    if (!Array.isArray(c.tiposDeDados) || !c.tiposDeDados.length || !c.tiposDeDados.every((t) => TIPOS.includes(t)))
      e.push(`"tiposDeDados" deve usar apenas: ${TIPOS.join(", ")}.`);
    if (!Number.isInteger(c.repeticoes) || c.repeticoes < 1 || c.repeticoes > 1000)
      e.push('"repeticoes" deve ser um inteiro entre 1 e 1000.');
    return e;
  }

  function estatisticas(t) {
    const o = [...t].sort((x, y) => x - y), n = o.length, m = n >> 1;
    return { media: t.reduce((s, x) => s + x, 0) / n, mediana: n % 2 ? o[m] : (o[m - 1] + o[m]) / 2,
             minimo: o[0], maximo: o[n - 1] };
  }

  // Executor: cópia idêntica dos dados para todos, N repetições, mede o tempo.
  async function executar(cfg, progresso) {
    const erros = validarConfig(cfg);
    if (erros.length) erro("Configuração inválida:\n- " + erros.join("\n- "));
    const prob = problemas.get(cfg.problema), linhas = [];
    const total = cfg.tamanhos.length * cfg.tiposDeDados.length * cfg.algoritmos.length; let feito = 0;
    for (const n of cfg.tamanhos) for (const tipo of cfg.tiposDeDados) {
      const entrada = prob.preparar(gerarDados(tipo, n, cfg.semente));
      for (const nome of cfg.algoritmos) {
        const alg = algoritmos.get(nome), tempos = [];
        for (let r = 0; r < cfg.repeticoes; r++) {
          const copia = structuredClone(entrada);
          const t0 = performance.now();
          try { alg.executar(copia); }
          catch (e) { erro(`Algoritmo '${nome}' falhou (n=${n}, ${tipo}): ${e.message}`); }
          tempos.push(performance.now() - t0);
        }
        linhas.push({ algoritmo: nome, tamanho: n, tipo, ...estatisticas(tempos) });
        await new Promise((r) => setTimeout(r, 0)); // deixa a tela respirar
        if (progresso) progresso(++feito / total);
      }
    }
    return linhas;
  }

  g.Benchy = { TIPOS, registrarProblema, registrar, listar, gerarDados, validarConfig, estatisticas, executar };
})(typeof window !== "undefined" ? window : globalThis);
