# Benchy: framework de comparação de algoritmos (sem Node.js)

Mede o tempo de execução de algoritmos para o mesmo problema, em condições idênticas.
JavaScript puro, roda no navegador. **Não precisa instalar nada.**

## Como usar
1. Extraia a pasta `benchy/`.
2. Dê dois cliques em `index.html` (Chrome, Edge ou Firefox).
3. Clique em **Exemplo: ordenação** (ou buscas) e depois em **▶ Executar**.
4. Para rodar os testes, abra `testes/testes.html`.

## Estrutura
```
benchy/
├── index.html            interface
├── nucleo/benchy.js      NÚCLEO (independente dos problemas)
├── aplicacoes/
│   ├── ordenacao.js      App 1: bubbleSort, quickSort, sortNativo
│   └── buscas.js         App 2: buscaLinear, buscaBinaria
├── configs/              experimentos em JSON
└── testes/               testes.html + testes.js
```

## Configuração (JSON)
| Campo | Descrição |
|---|---|
| `problema` | `"ordenacao"` ou `"buscas"` (ou outro registrado por você) |
| `algoritmos` | lista com pelo menos 2 nomes registrados |
| `tamanhos` | inteiros positivos, ex.: `[100, 1000]` |
| `tiposDeDados` | `aleatorio`, `ordenado`, `invertido` |
| `repeticoes` | inteiro de 1 a 1000 |
| `semente` | opcional; deixa os dados aleatórios reproduzíveis |

## Exemplo de entrada
```json
{ "problema": "buscas", "algoritmos": ["buscaLinear", "buscaBinaria"],
  "tamanhos": [1000, 100000], "tiposDeDados": ["aleatorio"], "repeticoes": 10 }
```

## Exemplo de saída (valores variam por máquina)
| Algoritmo | Tamanho | Dados | Média | Mediana | Mínimo | Máximo |
|---|---|---|---|---|---|---|
| buscaLinear | 100000 | aleatorio | 0.0712 | 0.0690 | 0.0650 | 0.0900 |
| buscaBinaria | 100000 | aleatorio | 0.0008 | 0.0000 | 0.0000 | 0.0050 |

## Criar sua própria aplicação
```js
Benchy.registrarProblema("meuProblema", { preparar: (dados) => dados });
Benchy.registrar({ nome: "meuAlgoritmo", descricao: "...", problema: "meuProblema",
  executar: (entrada) => /* devolve o resultado */ entrada });
```
Inclua o arquivo com `<script>` no `index.html`.

## Erros tratados (mensagens claras)
JSON malformado, problema ou algoritmo inexistente, menos de 2 algoritmos, tamanhos ou repetições
inválidos, tipo de dado desconhecido e algoritmo que lança exceção.

## Requisitos atendidos
**Específicos (6):** 67 (registro de algoritmos), 68 (mesma entrada para todos), 69 (dados aleatório,
ordenado e invertido), 70 (tempo com várias repetições), 71 (configuração de tamanhos, repetições e
algoritmos), 73 (média, mediana, mínimo e máximo).
**Gerais:** núcleo separado, configuração externa, 2 aplicações, tratamento de erros,
demonstração executável, documentação e testes.

## Limitações
- O navegador limita a precisão do relógio; tempos muito pequenos podem aparecer como 0.
- Tamanhos grandes no bubbleSort (ex.: 50.000) demoram bastante.
